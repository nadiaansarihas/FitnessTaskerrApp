# Stripe Premium Subscription Setup

This guide explains how to configure Stripe for the QuestLog premium subscription feature.

## Overview

QuestLog uses Stripe to handle premium subscriptions. Premium users get:
- ✨ Unlimited quest slots (free users limited to 10)
- 📊 Advanced progress analytics
- 🎨 Exclusive premium themes
- 🏆 Legendary rewards and achievements

## Setup Instructions

### 1. Create a Stripe Account

1. Visit [stripe.com](https://stripe.com) and sign up for an account
2. Enable **Test Mode** (toggle in the upper right corner of the Dashboard)
3. You'll use test mode to develop and test without real money

### 2. Get Your API Keys

From the Stripe Dashboard:

1. Click **Developers** in the top menu
2. Click **API keys** in the left sidebar
3. You'll see two keys:
   - **Publishable key** (starts with `pk_test_...`)
   - **Secret key** (starts with `sk_test_...`) - Click "Reveal test key token"

### 3. Create a Product and Price

1. Go to **Products** in the Stripe Dashboard
2. Click **+ Add Product**
3. Fill in:
   - Name: `QuestLog Premium`
   - Description: `Unlock unlimited quests and premium features`
   - Price: Choose your price (e.g., $9.99/month)
   - Billing period: `Monthly (recurring)`
4. Click **Save product**
5. After saving, click on the price you just created
6. Copy the **Price ID** (starts with `price_...`)

### 4. Configure Environment Variables

In Replit, add these secrets to your environment:

1. Click on the **Secrets** tab (🔒 icon) in the left sidebar
2. Add the following secrets:

```
STRIPE_SECRET_KEY=sk_test_YOUR_SECRET_KEY_HERE
STRIPE_PRICE_ID=price_YOUR_PRICE_ID_HERE
```

**Important:** 
- Use your **test mode** keys for development
- Never commit these keys to your code
- The app works without Stripe configured - it just shows an error when users try to upgrade

### 5. Test the Checkout Flow

1. Restart your application (it should auto-restart when you add secrets)
2. Sign in to QuestLog
3. Click the **UPGRADE NOW** button on the premium banner
4. You'll be redirected to Stripe Checkout
5. Use a [test card number](https://stripe.com/docs/testing):
   - Card: `4242 4242 4242 4242`
   - Expiry: Any future date (e.g., `12/34`)
   - CVC: Any 3 digits (e.g., `123`)
   - ZIP: Any 5 digits (e.g., `12345`)
6. Complete the checkout
7. You'll be redirected back to QuestLog with premium access!

### 6. Set Up Webhooks (Production Only)

For production deployments, you need to set up webhooks so Stripe can notify your app about subscription events:

1. In Stripe Dashboard, go to **Developers** → **Webhooks**
2. Click **+ Add endpoint**
3. Enter your webhook URL: `https://your-replit-url.replit.app/api/billing/webhook`
4. Select events to listen for:
   - `checkout.session.completed`
   - `customer.subscription.deleted`
5. Click **Add endpoint**
6. Copy the **Signing secret** (starts with `whsec_...`)
7. Add it to your environment variables as `STRIPE_WEBHOOK_SECRET`

## Testing Premium Features

### Test Premium Status

Once you've upgraded using a test card:

1. Check that the premium banner disappears
2. Create more than 10 quests (free tier limit)
3. Look for the `[ PREMIUM ]` indicator in the dashboard

### Test Subscription Cancellation

1. Go to Stripe Dashboard → **Customers**
2. Find your test customer
3. Click on their subscription
4. Click **Cancel subscription**
5. Reload QuestLog - premium features should be revoked

### Simulate Webhook Events (Development)

If you want to test webhooks locally:

1. Install Stripe CLI: [docs.stripe.com/stripe-cli](https://docs.stripe.com/stripe-cli)
2. Run: `stripe listen --forward-to localhost:5000/api/billing/webhook`
3. Use the webhook secret provided by the CLI in your `.env`
4. Trigger events: `stripe trigger checkout.session.completed`

## Architecture

### Database Schema

The `users` table includes these Stripe-related fields:
- `isPremium` (boolean) - Whether user has active premium subscription
- `stripeCustomerId` (varchar) - Stripe customer ID for this user
- `stripeSubscriptionId` (varchar) - Active subscription ID

### API Routes

- `POST /api/billing/create-checkout-session` - Create Stripe checkout for premium upgrade
- `POST /api/billing/webhook` - Handle Stripe webhook events

### Frontend Integration

- `<PremiumBanner />` - Shown to free users, initiates checkout flow
- Premium features automatically unlock when `user.isPremium === true`

## Troubleshooting

### "Stripe is not configured" Error

- Make sure you've added `STRIPE_SECRET_KEY` and `STRIPE_PRICE_ID` to your environment
- Restart your application after adding secrets
- Check that you're using the test mode keys (starting with `sk_test_`)

### Checkout Not Working

- Verify your Price ID is correct (starts with `price_`)
- Check browser console for errors
- Make sure you're using a valid test card number

### Webhooks Not Triggering

- In development, webhooks won't work without the Stripe CLI or a public URL
- For production, ensure your webhook URL is publicly accessible
- Check the webhook signature secret matches your environment variable

## Going to Production

When you're ready to accept real payments:

1. Complete Stripe account verification
2. Switch from Test Mode to Live Mode in Stripe Dashboard
3. Create a new product/price in Live Mode
4. Update your environment variables with **live mode** keys:
   - `STRIPE_SECRET_KEY` → `sk_live_...`
   - `STRIPE_PRICE_ID` → `price_...` (from live mode)
5. Set up production webhooks with live mode signing secret
6. Test thoroughly with a real card before launching!

## Support

For Stripe integration issues, check:
- [Stripe Documentation](https://stripe.com/docs)
- [Stripe Testing Guide](https://stripe.com/docs/testing)
- [Stripe API Reference](https://stripe.com/docs/api)
