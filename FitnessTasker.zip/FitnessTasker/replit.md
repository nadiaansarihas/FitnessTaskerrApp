# QuestLog - Fitness RPG Tracker

## Overview

QuestLog is a gamified fitness and nutrition tracking application that transforms health goals into an RPG-style adventure. Users create "quests" representing fitness tasks (movement, nutrition, recovery, mindset), complete them to earn XP, level up, and track progress across multiple categories. The app features a free tier with limited quest slots and a premium subscription tier powered by Stripe that unlocks unlimited quests and additional features.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework & Build System**
- **React 18** with functional components and hooks for the UI layer
- **Vite** as the build tool and development server
- **TypeScript** for type safety across the entire codebase
- **Wouter** for lightweight client-side routing (landing page, dashboard, premium success/cancel pages)

**State Management**
- **TanStack Query (React Query)** for server state management, caching, and data fetching
- Local React state (useState, useEffect) for UI-specific state
- Custom hooks for reusable logic (useAuth for authentication state)

**UI Component Library**
- **Radix UI** primitives for accessible, unstyled components
- **shadcn/ui** component system built on Radix UI
- **Tailwind CSS v4** with custom design tokens for styling
- **Framer Motion** for animations and transitions
- Custom gaming theme with neon color palette (Movement: blue, Nutrition: green, Recovery: purple, Mindset: orange)

**Design Decisions**
- Gaming/RPG aesthetic with "Chakra Petch" display font and "Inter" for readability
- Dark theme with neon accents and hex grid background imagery
- Responsive design supporting both mobile and desktop viewports
- Category-based color coding throughout the UI for visual consistency

### Backend Architecture

**Server Framework**
- **Express.js** running on Node.js for the HTTP server
- **TypeScript** for type-safe server code
- **esbuild** for production bundling with allowlisted dependencies to reduce cold start times

**Authentication**
- **Replit Auth** via OpenID Connect (OIDC) for user authentication
- **Passport.js** with openid-client strategy for OAuth integration
- **Express Session** with PostgreSQL session store for persistent sessions
- JWT-style tokens (access_token, refresh_token) managed through OIDC

**API Design**
- RESTful API endpoints organized by domain:
  - `/api/auth/*` - Authentication and user management
  - `/api/quests/*` - Quest CRUD operations
  - `/api/billing/*` - Stripe payment integration
- Authentication middleware (`isAuthenticated`) protects all quest and user endpoints
- Request logging with formatted timestamps and duration tracking

**Database Design**
- Three primary tables:
  - `sessions` - Express session storage (required by Replit Auth)
  - `users` - User accounts with premium subscription fields
  - `quests` - User quests with category, difficulty, XP, calories, completion status
- Foreign key cascade deletes ensure data integrity
- PostgreSQL with Drizzle ORM for type-safe database queries

### Data Storage Solutions

**ORM & Database Client**
- **Drizzle ORM** for TypeScript-native database access
- **@neondatabase/serverless** with WebSocket support for Neon PostgreSQL
- Schema-first approach with TypeScript types generated from schema definitions
- Migration system via drizzle-kit for schema changes

**Schema Design**
- `users` table stores: id (UUID), email, name, profile image, premium status (isPremium, stripeCustomerId, stripeSubscriptionId), timestamps
- `quests` table stores: id (UUID), userId (FK), title, category, difficulty, XP value, calories, completed boolean, timestamps
- Shared schema file (`shared/schema.ts`) used by both client and server for type consistency

**Storage Layer**
- Database storage interface (`IStorage`) abstracts database operations
- Storage methods handle user upserts, quest CRUD, premium status updates
- Uses Drizzle's query builder with eq/and/desc operators for filtering and sorting

### Authentication and Authorization

**Authentication Flow**
1. User initiates login via `/api/login` endpoint
2. Redirected to Replit OIDC provider for authentication
3. OAuth callback returns with authorization code
4. Server exchanges code for access/refresh tokens
5. User claims stored in session, tokens refreshed as needed
6. Session persists in PostgreSQL for 7 days

**Authorization Strategy**
- Session-based authentication with HTTP-only secure cookies
- `isAuthenticated` middleware checks for valid session on protected routes
- User ID extracted from session claims (req.user.claims.sub)
- All quest operations filtered by userId to ensure data isolation

**Security Measures**
- HTTPS-only cookies in production
- Session secret from environment variables
- Automatic session cleanup via PostgreSQL TTL
- User data never exposed without authentication

### External Dependencies

**Payment Processing**
- **Stripe** (API version 2025-11-17.clover) for premium subscriptions
- Checkout Session flow: create session → redirect to Stripe → handle webhook
- Webhook endpoint (`/api/billing/webhook`) processes subscription events
- Premium status (isPremium) toggled upon successful payment confirmation
- Environment-based configuration (STRIPE_SECRET_KEY, STRIPE_PRICE_ID)

**Database Provider**
- **Neon PostgreSQL** (serverless PostgreSQL)
- Connection via DATABASE_URL environment variable
- WebSocket-based connections for serverless compatibility

**Third-Party Libraries**
- **zod** for runtime schema validation (form inputs, API requests)
- **react-hook-form** with zod resolver for form state management
- **date-fns** for date formatting and manipulation
- **nanoid** for generating unique IDs
- **bcrypt** referenced in documentation but not actively used (Replit Auth handles password hashing)

**Development Tools**
- **Replit-specific plugins**: cartographer (source maps), dev banner, runtime error overlay
- Custom Vite plugin for updating OpenGraph meta tags with deployment URLs

**Environment Variables**
- `DATABASE_URL` - PostgreSQL connection string (required)
- `ISSUER_URL` - Replit OIDC provider URL (defaults to https://replit.com/oidc)
- `REPL_ID` - Replit application identifier
- `SESSION_SECRET` - Express session encryption key
- `STRIPE_SECRET_KEY` - Stripe API secret (optional, premium features disabled without it)
- `STRIPE_PRICE_ID` - Stripe price ID for premium subscription
- `NODE_ENV` - Environment mode (development/production)