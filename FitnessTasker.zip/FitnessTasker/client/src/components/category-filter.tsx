import { Category } from "@/lib/types";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface CategoryFilterProps {
  selected: Category | 'All';
  onSelect: (category: Category | 'All') => void;
}

const categories: (Category | 'All')[] = ['All', 'Movement', 'Nutrition', 'Recovery', 'Mindset', 'Other'];

export function CategoryFilter({ selected, onSelect }: CategoryFilterProps) {
  return (
    <div className="flex flex-wrap gap-2 mb-6">
      {categories.map((cat) => (
        <Button
          key={cat}
          variant="outline"
          size="sm"
          onClick={() => onSelect(cat)}
          className={cn(
            "border-dashed transition-all duration-300 font-display tracking-wide text-xs",
            selected === cat 
              ? "bg-primary text-primary-foreground border-primary border-solid shadow-[0_0_10px_hsla(var(--primary),0.5)]" 
              : "text-muted-foreground hover:text-foreground hover:border-primary/50"
          )}
        >
          {cat === 'All' ? 'ALL QUESTS' : cat.toUpperCase()}
        </Button>
      ))}
    </div>
  );
}
