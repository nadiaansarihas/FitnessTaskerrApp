import { Quest, Category, CATEGORY_BG_COLORS, CATEGORY_COLORS } from "@/lib/types";
import { Progress } from "@/components/ui/progress";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Flame, Trophy, Zap } from "lucide-react";

interface StatsPanelProps {
  quests: Quest[];
  xp: number;
  level: number;
  nextLevelXp: number;
}

export function StatsPanel({ quests, xp, level, nextLevelXp }: StatsPanelProps) {
  // Calculate Category Progress
  const categories: Category[] = ['Movement', 'Nutrition', 'Recovery', 'Mindset', 'Other'];
  
  const getCategoryProgress = (cat: Category) => {
    const catQuests = quests.filter(q => q.category === cat);
    if (catQuests.length === 0) return 0;
    const completed = catQuests.filter(q => q.completed).length;
    return Math.round((completed / catQuests.length) * 100);
  };

  // Calculate Calories
  const caloriesConsumed = quests
    .filter(q => q.completed && (q.calories || 0) > 0)
    .reduce((sum, q) => sum + (q.calories || 0), 0);
    
  const caloriesBurned = quests
    .filter(q => q.completed && (q.calories || 0) < 0)
    .reduce((sum, q) => sum + Math.abs(q.calories || 0), 0);

  const completedToday = quests.filter(q => q.completed).length;
  const totalQuests = quests.length;
  const overallProgress = totalQuests > 0 ? Math.round((completedToday / totalQuests) * 100) : 0;

  return (
    <div className="space-y-6 sticky top-6">
      {/* Player Card */}
      <Card className="border-primary/50 bg-card/80 backdrop-blur-md shadow-[0_0_30px_rgba(0,0,0,0.3)] overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-primary to-transparent opacity-50" />
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center justify-between">
            <span className="font-display text-xl text-primary text-glow">PLAYER STATS</span>
            <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 border border-primary/20">
              <Trophy className="w-4 h-4 text-yellow-500" />
              <span className="font-mono font-bold text-yellow-500">LVL {level}</span>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <div className="flex justify-between text-xs font-mono text-muted-foreground">
              <span>XP PROGRESS</span>
              <span>{xp} / {nextLevelXp} XP</span>
            </div>
            <Progress value={(xp / nextLevelXp) * 100} className="h-3 bg-secondary" indicatorClassName="bg-yellow-500 shadow-[0_0_10px_rgba(234,179,8,0.5)]" />
          </div>

          <div className="grid grid-cols-2 gap-4 pt-2">
            <div className="bg-background/50 p-3 rounded-md border border-border text-center">
              <div className="text-xs text-muted-foreground font-mono mb-1">QUESTS</div>
              <div className="text-2xl font-display text-foreground">{completedToday}/{totalQuests}</div>
            </div>
            <div className="bg-background/50 p-3 rounded-md border border-border text-center">
              <div className="text-xs text-muted-foreground font-mono mb-1">STREAK</div>
              <div className="text-2xl font-display text-primary flex items-center justify-center gap-1">
                <Zap className="w-4 h-4 fill-current" />
                3
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Calories Module */}
      <Card className="border-border/50 bg-card/60 backdrop-blur-sm">
        <CardHeader className="pb-2">
          <CardTitle className="font-display text-sm text-muted-foreground flex items-center gap-2">
            <Flame className="w-4 h-4" />
            ENERGY METRICS
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex justify-between items-center">
            <span className="text-sm text-green-400">Consumed</span>
            <span className="font-mono font-bold text-green-400">+{caloriesConsumed}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm text-red-400">Burned</span>
            <span className="font-mono font-bold text-red-400">-{caloriesBurned}</span>
          </div>
          <div className="h-px bg-border my-2" />
          <div className="flex justify-between items-center">
            <span className="text-sm font-bold text-foreground">Net Energy</span>
            <span className="font-mono font-bold text-foreground">{caloriesConsumed - caloriesBurned}</span>
          </div>
        </CardContent>
      </Card>

      {/* Category Skills */}
      <Card className="border-border/50 bg-card/60 backdrop-blur-sm">
        <CardHeader className="pb-2">
          <CardTitle className="font-display text-sm text-muted-foreground">
            SKILL MASTERY
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {categories.map(cat => (
            <div key={cat} className="space-y-1.5">
              <div className="flex justify-between text-xs">
                <span className={CATEGORY_COLORS[cat].split(' ')[0]}>{cat}</span>
                <span className="font-mono text-muted-foreground">{getCategoryProgress(cat)}%</span>
              </div>
              <Progress 
                value={getCategoryProgress(cat)} 
                className="h-1.5 bg-secondary" 
                indicatorClassName={CATEGORY_BG_COLORS[cat]} 
              />
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}
