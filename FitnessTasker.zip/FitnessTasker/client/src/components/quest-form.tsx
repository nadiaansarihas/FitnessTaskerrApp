import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Plus, Sword } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { CATEGORY_COLORS, DIFFICULTY_XP, WORKOUT_TYPES, WORKOUT_TYPE_COLORS, WorkoutType } from "@/lib/types";
import { motion } from "framer-motion";

const formSchema = z.object({
  title: z.string().min(2, "Quest title must be at least 2 characters"),
  category: z.enum(['Movement', 'Nutrition', 'Recovery', 'Mindset', 'Other'] as const),
  difficulty: z.enum(['Easy', 'Normal', 'Epic'] as const),
  workoutType: z.string().optional(),
  calories: z.string().optional(),
});

interface QuestFormProps {
  onAddQuest: (quest: { title: string; category: string; difficulty: string; workoutType?: string; calories: number }) => void;
}

export function QuestForm({ onAddQuest }: QuestFormProps) {
  const [isExpanded, setIsExpanded] = useState(false);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: "",
      category: "Movement",
      difficulty: "Normal",
      workoutType: "",
      calories: "",
    },
  });

  const watchCategory = form.watch("category");
  const showWorkoutType = watchCategory === "Movement";

  function onSubmit(values: z.infer<typeof formSchema>) {
    onAddQuest({
      title: values.title,
      category: values.category,
      difficulty: values.difficulty,
      workoutType: values.workoutType || undefined,
      calories: values.calories ? parseInt(values.calories, 10) : 0,
    });
    form.reset();
    setIsExpanded(false);
  }

  return (
    <div className="w-full mb-8">
      {!isExpanded ? (
        <Button 
          onClick={() => setIsExpanded(true)}
          className="w-full h-14 text-lg font-display tracking-wider border-2 border-dashed border-primary/30 bg-background/50 hover:bg-primary/10 hover:border-primary hover:text-primary transition-all group"
          variant="outline"
          data-testid="button-new-quest"
        >
          <Plus className="mr-2 h-5 w-5 group-hover:rotate-90 transition-transform" />
          NEW QUEST
        </Button>
      ) : (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: "auto" }}
          exit={{ opacity: 0, height: 0 }}
          className="bg-card/90 backdrop-blur-md border border-primary/20 rounded-lg p-6 shadow-2xl shadow-primary/5"
        >
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-primary font-display">Quest Objective</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="e.g., Run 5km" 
                        {...field} 
                        className="bg-background/50 border-primary/20 focus:border-primary" 
                        data-testid="input-quest-title"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="category"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-muted-foreground font-mono text-xs">REALM</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger className="bg-background/50 border-primary/20" data-testid="select-category">
                            <SelectValue placeholder="Select Realm" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {Object.keys(CATEGORY_COLORS).map((cat) => (
                            <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="difficulty"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-muted-foreground font-mono text-xs">DIFFICULTY</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger className="bg-background/50 border-primary/20" data-testid="select-difficulty">
                            <SelectValue placeholder="Select Difficulty" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="Easy" className="text-diff-easy">Easy (+{DIFFICULTY_XP.Easy} XP)</SelectItem>
                          <SelectItem value="Normal" className="text-diff-normal">Normal (+{DIFFICULTY_XP.Normal} XP)</SelectItem>
                          <SelectItem value="Epic" className="text-diff-epic font-bold">Epic (+{DIFFICULTY_XP.Epic} XP)</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              {showWorkoutType && (
                <FormField
                  control={form.control}
                  name="workoutType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-muted-foreground font-mono text-xs">WORKOUT TYPE (OPTIONAL)</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger className="bg-background/50 border-primary/20" data-testid="select-workout-type">
                            <SelectValue placeholder="Select workout type..." />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="">None</SelectItem>
                          {WORKOUT_TYPES.map((type) => {
                            const colors = WORKOUT_TYPE_COLORS[type as WorkoutType];
                            return (
                              <SelectItem key={type} value={type} className={colors}>
                                {type}
                              </SelectItem>
                            );
                          })}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}

              <FormField
                control={form.control}
                name="calories"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-muted-foreground font-mono text-xs">CALORIES (OPTIONAL)</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        placeholder="+Consumed or -Burned" 
                        {...field} 
                        className="bg-background/50 border-primary/20" 
                        data-testid="input-calories"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="flex gap-2 pt-2">
                <Button 
                  type="submit" 
                  className="flex-1 bg-primary text-primary-foreground hover:bg-primary/90 font-display tracking-wider"
                  data-testid="button-accept-quest"
                >
                  <Sword className="mr-2 h-4 w-4" />
                  ACCEPT QUEST
                </Button>
                <Button 
                  type="button" 
                  variant="secondary" 
                  onClick={() => setIsExpanded(false)}
                  data-testid="button-cancel-quest"
                >
                  Cancel
                </Button>
              </div>
            </form>
          </Form>
        </motion.div>
      )}
    </div>
  );
}
