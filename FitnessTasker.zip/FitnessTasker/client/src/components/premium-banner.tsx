import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Crown, Sparkles, X } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export function PremiumBanner() {
  const [dismissed, setDismissed] = useState(false);
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const handleUpgrade = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/billing/create-checkout-session", {
        method: "POST",
      });

      if (!res.ok) {
        throw new Error("Failed to create checkout session");
      }

      const { url } = await res.json();
      window.location.href = url;
    } catch (error) {
      setLoading(false);
      toast({
        title: "Error",
        description: "Failed to start upgrade process. Please try again.",
        variant: "destructive",
      });
    }
  };

  if (dismissed) return null;

  return (
    <Card className="mb-6 bg-gradient-to-br from-yellow-500/10 to-purple-500/10 border-yellow-500/30 p-6 backdrop-blur-md relative">
      <button
        onClick={() => setDismissed(true)}
        className="absolute top-4 right-4 text-muted-foreground hover:text-foreground transition-colors"
      >
        <X className="w-4 h-4" />
      </button>

      <div className="flex flex-col md:flex-row items-center gap-6">
        <div className="flex-shrink-0">
          <div className="relative">
            <Crown className="w-16 h-16 text-yellow-500 animate-pulse" />
            <Sparkles className="w-6 h-6 text-yellow-300 absolute -top-1 -right-1" />
          </div>
        </div>

        <div className="flex-grow text-center md:text-left">
          <h3 className="text-2xl font-display font-bold text-yellow-500 mb-2">
            UNLOCK PREMIUM
          </h3>
          <p className="text-muted-foreground mb-3">
            Get unlimited quests, advanced analytics, exclusive themes, and premium-only rewards. Level up to legendary status!
          </p>
          <ul className="text-sm text-muted-foreground space-y-1">
            <li>✨ Unlimited quest slots (free users limited to 10)</li>
            <li>📊 Advanced progress analytics and insights</li>
            <li>🎨 Exclusive premium themes and customization</li>
            <li>🏆 Access to legendary rewards and achievements</li>
          </ul>
        </div>

        <div className="flex-shrink-0">
          <Button
            onClick={handleUpgrade}
            disabled={loading}
            className="bg-yellow-500 text-black hover:bg-yellow-600 font-display tracking-wider px-8 h-12 text-lg shadow-[0_0_20px_rgba(234,179,8,0.3)]"
            data-testid="button-upgrade-premium"
          >
            {loading ? (
              "PROCESSING..."
            ) : (
              <>
                <Crown className="mr-2 h-5 w-5" />
                UPGRADE NOW
              </>
            )}
          </Button>
        </div>
      </div>
    </Card>
  );
}
