import React, { useState, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Plus, Check, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

interface QuickAddProps {
  onAdd: (title: string) => void;
}

export function QuickAdd({ onAdd }: QuickAddProps) {
  const [title, setTitle] = useState("");
  const [showSuccess, setShowSuccess] = useState(false);
  const [isFocused, setIsFocused] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleSubmit = () => {
    if (title.trim()) {
      onAdd(title.trim());
      setTitle("");
      setShowSuccess(true);
      setTimeout(() => setShowSuccess(false), 2000);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && title.trim()) {
      e.preventDefault();
      handleSubmit();
    }
  };

  return (
    <div className="relative mb-6" data-testid="quick-add">
      <motion.div
        className={cn(
          "flex items-center gap-2 p-2 rounded-lg border-2 transition-all duration-300",
          "bg-card/50 backdrop-blur-sm",
          isFocused 
            ? "border-primary shadow-lg shadow-primary/20" 
            : "border-muted/30 hover:border-muted"
        )}
        animate={{ scale: isFocused ? 1.01 : 1 }}
        transition={{ duration: 0.2 }}
      >
        <Zap className={cn(
          "w-5 h-5 ml-2 transition-colors duration-300",
          isFocused ? "text-primary" : "text-muted-foreground"
        )} />
        
        <Input
          ref={inputRef}
          type="text"
          placeholder="Quick add quest... (Enter to submit)"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          onKeyDown={handleKeyDown}
          onFocus={() => setIsFocused(true)}
          onBlur={() => setIsFocused(false)}
          className="flex-grow border-0 bg-transparent focus-visible:ring-0 focus-visible:ring-offset-0 text-lg placeholder:text-muted-foreground/50"
          data-testid="input-quick-add"
        />
        
        <Button
          onClick={handleSubmit}
          disabled={!title.trim()}
          size="icon"
          className={cn(
            "h-10 w-10 rounded-full transition-all duration-300",
            title.trim() 
              ? "bg-primary text-primary-foreground hover:bg-primary/90" 
              : "bg-muted text-muted-foreground"
          )}
          data-testid="button-quick-add"
        >
          <motion.div
            animate={{ rotate: title.trim() ? 0 : 0 }}
            whileHover={{ rotate: 90 }}
            transition={{ duration: 0.2 }}
          >
            <Plus className="h-5 w-5" />
          </motion.div>
        </Button>
      </motion.div>

      {/* Hint text */}
      <AnimatePresence>
        {isFocused && (
          <motion.p
            initial={{ opacity: 0, y: -5 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -5 }}
            className="text-xs text-muted-foreground mt-2 ml-2 font-mono"
          >
            Auto-assigns to "Other" category with Normal difficulty (+150 XP)
          </motion.p>
        )}
      </AnimatePresence>

      {/* Success Message */}
      <AnimatePresence>
        {showSuccess && (
          <motion.div
            initial={{ opacity: 0, y: 10, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -10, scale: 0.9 }}
            className="absolute top-full left-0 right-0 mt-2 flex items-center justify-center"
          >
            <div className="bg-green-500/20 border border-green-500/50 rounded-lg px-4 py-2 flex items-center gap-2">
              <Check className="w-4 h-4 text-green-500" />
              <span className="text-sm text-green-500 font-mono">Quest added successfully!</span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
