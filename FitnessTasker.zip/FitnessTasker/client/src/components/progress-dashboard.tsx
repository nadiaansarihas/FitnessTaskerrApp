import { useMemo } from "react";
import { motion } from "framer-motion";
import { Quest, Category, CATEGORY_COLORS, CATEGORY_BG_COLORS } from "@/lib/types";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Activity, Flame, BedDouble, Brain, Star, TrendingUp, CheckCircle2, Target } from "lucide-react";

interface ProgressDashboardProps {
  quests: Quest[];
}

const CategoryIcons: Record<Category, typeof Activity> = {
  Movement: Activity,
  Nutrition: Flame,
  Recovery: BedDouble,
  Mindset: Brain,
  Other: Star,
};

export function ProgressDashboard({ quests }: ProgressDashboardProps) {
  const stats = useMemo(() => {
    const total = quests.length;
    const completed = quests.filter(q => q.completed).length;
    const percentage = total > 0 ? Math.round((completed / total) * 100) : 0;
    
    const today = new Date().toDateString();
    const todayQuests = quests.filter(q => {
      const questDate = new Date(q.createdAt).toDateString();
      return questDate === today;
    });
    const todayCompleted = todayQuests.filter(q => q.completed).length;
    const todayTotal = todayQuests.length;
    
    const categories: Record<string, { total: number; completed: number }> = {};
    quests.forEach(q => {
      if (!categories[q.category]) {
        categories[q.category] = { total: 0, completed: 0 };
      }
      categories[q.category].total++;
      if (q.completed) {
        categories[q.category].completed++;
      }
    });
    
    return { total, completed, percentage, todayTotal, todayCompleted, categories };
  }, [quests]);

  const circumference = 2 * Math.PI * 45;
  const strokeDashoffset = circumference - (stats.percentage / 100) * circumference;

  return (
    <Card className="bg-card/60 backdrop-blur-md border-primary/20 p-6 mb-6" data-testid="progress-dashboard">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Circular Progress */}
        <div className="flex flex-col items-center justify-center">
          <div className="relative w-32 h-32">
            <svg className="w-full h-full transform -rotate-90">
              <defs>
                <linearGradient id="progressGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="hsl(var(--primary))" />
                  <stop offset="50%" stopColor="#60a5fa" />
                  <stop offset="100%" stopColor="#a855f7" />
                </linearGradient>
              </defs>
              <circle
                cx="64"
                cy="64"
                r="45"
                fill="none"
                stroke="hsl(var(--muted))"
                strokeWidth="8"
                className="opacity-20"
              />
              <motion.circle
                cx="64"
                cy="64"
                r="45"
                fill="none"
                stroke="url(#progressGradient)"
                strokeWidth="8"
                strokeLinecap="round"
                strokeDasharray={circumference}
                initial={{ strokeDashoffset: circumference }}
                animate={{ strokeDashoffset }}
                transition={{ duration: 1, ease: "easeOut" }}
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <motion.span 
                className="text-3xl font-display font-bold bg-gradient-to-r from-primary via-blue-400 to-purple-500 bg-clip-text text-transparent"
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 0.5, type: "spring" }}
              >
                {stats.percentage}%
              </motion.span>
              <span className="text-xs text-muted-foreground font-mono">COMPLETE</span>
            </div>
          </div>
          <div className="mt-2 text-center">
            <p className="text-sm text-muted-foreground font-mono">
              {stats.completed} / {stats.total} Quests
            </p>
          </div>
        </div>

        {/* Category Progress Bars */}
        <div className="space-y-3">
          <h3 className="text-sm font-display text-primary mb-2 flex items-center gap-2">
            <Target className="w-4 h-4" />
            CATEGORY PROGRESS
          </h3>
          {Object.entries(stats.categories).map(([category, data]) => {
            const Icon = CategoryIcons[category as Category] || Star;
            const percentage = data.total > 0 ? Math.round((data.completed / data.total) * 100) : 0;
            const bgColor = CATEGORY_BG_COLORS[category as Category] || 'bg-muted';
            
            return (
              <div key={category} className="space-y-1" data-testid={`progress-category-${category.toLowerCase()}`}>
                <div className="flex justify-between items-center text-xs">
                  <span className={`flex items-center gap-1 font-mono ${CATEGORY_COLORS[category as Category]?.split(' ')[0]}`}>
                    <Icon className="w-3 h-3" />
                    {category}
                  </span>
                  <span className="text-muted-foreground">
                    {data.completed}/{data.total}
                  </span>
                </div>
                <div className="h-2 bg-muted/30 rounded-full overflow-hidden">
                  <motion.div
                    className={`h-full rounded-full ${bgColor}`}
                    initial={{ width: 0 }}
                    animate={{ width: `${percentage}%` }}
                    transition={{ duration: 0.8, ease: "easeOut", delay: 0.2 }}
                  />
                </div>
              </div>
            );
          })}
          {Object.keys(stats.categories).length === 0 && (
            <p className="text-xs text-muted-foreground text-center py-4">
              No quests yet. Create your first quest!
            </p>
          )}
        </div>

        {/* Today's Stats */}
        <div className="space-y-4">
          <h3 className="text-sm font-display text-primary mb-2 flex items-center gap-2">
            <TrendingUp className="w-4 h-4" />
            TODAY'S PROGRESS
          </h3>
          
          <div className="bg-gradient-to-br from-primary/20 to-purple-500/20 rounded-lg p-4 border border-primary/30">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-mono text-muted-foreground">COMPLETED TODAY</span>
              <CheckCircle2 className="w-4 h-4 text-green-500" />
            </div>
            <div className="flex items-baseline gap-2">
              <motion.span 
                className="text-4xl font-display font-bold text-primary"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
              >
                {stats.todayCompleted}
              </motion.span>
              <span className="text-muted-foreground font-mono text-sm">
                / {stats.todayTotal} quests
              </span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div className="bg-card/50 rounded-lg p-3 border border-muted/30">
              <p className="text-xs font-mono text-muted-foreground mb-1">TOTAL QUESTS</p>
              <p className="text-xl font-display font-bold">{stats.total}</p>
            </div>
            <div className="bg-card/50 rounded-lg p-3 border border-muted/30">
              <p className="text-xs font-mono text-muted-foreground mb-1">ALL COMPLETED</p>
              <p className="text-xl font-display font-bold text-green-500">{stats.completed}</p>
            </div>
          </div>
        </div>
      </div>
    </Card>
  );
}
