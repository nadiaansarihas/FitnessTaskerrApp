import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Check, Trash2, Pencil, Sword, Flame, Brain, BedDouble, Star, Activity, X, Save } from "lucide-react";
import { Quest, Category, Difficulty, CATEGORY_COLORS, DIFFICULTY_COLORS, DIFFICULTY_XP } from "@/lib/types";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";

interface QuestCardProps {
  quest: Quest;
  onToggle: (id: string) => void;
  onDelete: (id: string) => void;
  onEdit?: (id: string, updates: Partial<Quest>) => void;
}

const CategoryIcons: Record<Category, typeof Activity> = {
  Movement: Activity,
  Nutrition: Flame,
  Recovery: BedDouble,
  Mindset: Brain,
  Other: Star,
};

const PRIORITY_COLORS: Record<Difficulty, string> = {
  Epic: 'bg-red-500 text-white',
  Normal: 'bg-yellow-500 text-black',
  Easy: 'bg-green-500 text-white',
};

const PRIORITY_LABELS: Record<Difficulty, string> = {
  Epic: 'High',
  Normal: 'Medium',
  Easy: 'Low',
};

export function QuestCard({ quest, onToggle, onDelete, onEdit }: QuestCardProps) {
  const [isHovered, setIsHovered] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [editTitle, setEditTitle] = useState(quest.title);
  
  const Icon = CategoryIcons[quest.category as Category] || Star;
  const difficulty = quest.difficulty as Difficulty;

  const handleSaveEdit = () => {
    if (onEdit && editTitle.trim() !== quest.title) {
      onEdit(quest.id, { title: editTitle.trim() });
    }
    setIsEditing(false);
  };

  const handleCancelEdit = () => {
    setEditTitle(quest.title);
    setIsEditing(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSaveEdit();
    } else if (e.key === 'Escape') {
      handleCancelEdit();
    }
  };

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, x: -100 }}
      whileHover={{ scale: 1.01 }}
      transition={{ duration: 0.2 }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <Card 
        className={cn(
          "relative overflow-hidden border-l-4 bg-card/50 backdrop-blur-sm",
          "transition-all duration-300 ease-in-out",
          "hover:shadow-lg hover:shadow-primary/10",
          quest.completed ? "opacity-60" : "",
          CATEGORY_COLORS[quest.category as Category]?.split(' ')[1] || 'border-muted'
        )}
        data-testid={`card-quest-${quest.id}`}
      >
        <div className="p-4 flex items-center gap-4">
          {/* Checkbox */}
          <motion.button
            className={cn(
              "flex-shrink-0 h-10 w-10 rounded-full border-2 flex items-center justify-center",
              "transition-all duration-300 ease-in-out cursor-pointer",
              quest.completed 
                ? "bg-primary border-primary text-primary-foreground" 
                : "border-muted-foreground/30 hover:border-primary hover:bg-primary/10"
            )}
            onClick={() => onToggle(quest.id)}
            whileTap={{ scale: 0.9 }}
            data-testid={`checkbox-quest-${quest.id}`}
          >
            <AnimatePresence mode="wait">
              {quest.completed && (
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  exit={{ scale: 0 }}
                  transition={{ duration: 0.15 }}
                >
                  <Check className="h-5 w-5" />
                </motion.div>
              )}
            </AnimatePresence>
          </motion.button>

          {/* Content */}
          <div className="flex-grow space-y-2 min-w-0">
            {/* Badges Row */}
            <div className="flex items-center gap-2 flex-wrap">
              {/* Priority Badge */}
              <motion.span 
                className={cn(
                  "text-xs font-bold uppercase tracking-wider px-2 py-0.5 rounded-full",
                  "transition-all duration-300",
                  PRIORITY_COLORS[difficulty]
                )}
                whileHover={{ scale: 1.05 }}
                data-testid={`badge-priority-${quest.id}`}
              >
                {PRIORITY_LABELS[difficulty]}
              </motion.span>

              {/* Category Tag */}
              <motion.span 
                className={cn(
                  "text-xs font-bold uppercase tracking-wider px-2 py-0.5 rounded-sm border",
                  "transition-all duration-300 flex items-center gap-1",
                  CATEGORY_COLORS[quest.category as Category]
                )}
                whileHover={{ scale: 1.05 }}
                data-testid={`badge-category-${quest.id}`}
              >
                <Icon className="w-3 h-3" />
                {quest.category}
              </motion.span>

              {/* Difficulty Badge */}
              <span className={cn(
                "text-xs font-bold px-2 py-0.5 rounded-sm border flex items-center gap-1",
                "transition-all duration-300",
                DIFFICULTY_COLORS[difficulty]
              )}>
                <Sword className="w-3 h-3" />
                {quest.difficulty}
              </span>
            </div>
            
            {/* Title */}
            {isEditing ? (
              <div className="flex items-center gap-2">
                <Input
                  value={editTitle}
                  onChange={(e) => setEditTitle(e.target.value)}
                  onKeyDown={handleKeyDown}
                  className="flex-grow bg-background/50"
                  autoFocus
                  data-testid={`input-edit-${quest.id}`}
                />
                <Button size="icon" variant="ghost" onClick={handleSaveEdit} className="text-green-500 hover:text-green-400">
                  <Save className="h-4 w-4" />
                </Button>
                <Button size="icon" variant="ghost" onClick={handleCancelEdit} className="text-red-500 hover:text-red-400">
                  <X className="h-4 w-4" />
                </Button>
              </div>
            ) : (
              <motion.h3 
                className={cn(
                  "font-display text-lg font-semibold tracking-wide truncate",
                  "transition-all duration-300",
                  quest.completed && "line-through text-muted-foreground"
                )}
                layout
              >
                {quest.title}
              </motion.h3>
            )}
            
            {/* Stats */}
            <div className="flex items-center gap-4 text-xs text-muted-foreground font-mono">
              <span className="text-primary font-semibold">+{quest.xp} XP</span>
              {quest.calories !== null && quest.calories !== 0 && (
                <span>{quest.calories > 0 ? '+' : ''}{quest.calories} kCal</span>
              )}
            </div>
          </div>

          {/* Action Buttons - Show on hover */}
          <AnimatePresence>
            {(isHovered || isEditing) && !quest.completed && (
              <motion.div 
                className="flex items-center gap-1"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                transition={{ duration: 0.2 }}
              >
                {!isEditing && onEdit && (
                  <Button
                    variant="ghost"
                    size="icon"
                    className="text-muted-foreground hover:text-primary hover:bg-primary/10 transition-all duration-200"
                    onClick={() => setIsEditing(true)}
                    data-testid={`button-edit-${quest.id}`}
                  >
                    <Pencil className="h-4 w-4" />
                  </Button>
                )}
                <Button
                  variant="ghost"
                  size="icon"
                  className="text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-all duration-200"
                  onClick={() => onDelete(quest.id)}
                  data-testid={`button-delete-${quest.id}`}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Always visible delete for completed quests */}
          {quest.completed && (
            <Button
              variant="ghost"
              size="icon"
              className="text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-all duration-200"
              onClick={() => onDelete(quest.id)}
              data-testid={`button-delete-${quest.id}`}
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          )}
        </div>
        
        {/* Completion shine effect */}
        {quest.completed && (
          <motion.div
            initial={{ x: "-100%" }}
            animate={{ x: "100%" }}
            transition={{ duration: 0.5 }}
            className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent skew-x-12 pointer-events-none"
          />
        )}
      </Card>
    </motion.div>
  );
}
