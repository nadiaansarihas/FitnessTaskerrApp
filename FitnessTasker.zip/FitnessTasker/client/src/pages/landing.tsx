import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Sword, Trophy, Zap, Shield, Crown } from "lucide-react";
import generatedImage from '@assets/generated_images/dark_sci-fi_hex_grid_background.png';

export default function Landing() {
  return (
    <div className="min-h-screen text-foreground font-sans selection:bg-primary/30">
      {/* Background Image Layer */}
      <div className="fixed inset-0 z-[-1] opacity-20 pointer-events-none">
        <img src={generatedImage} alt="" className="w-full h-full object-cover" />
      </div>
      
      <div className="container mx-auto px-4 py-16">
        {/* Hero Section */}
        <div className="text-center mb-16">
          <h1 className="text-6xl md:text-8xl font-display font-bold bg-gradient-to-r from-primary via-blue-400 to-purple-500 bg-clip-text text-transparent mb-6 animate-pulse">
            QUESTLOG
          </h1>
          <p className="text-2xl md:text-3xl text-muted-foreground mb-4 font-display">
            LEVEL UP YOUR LIFE
          </p>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-8">
            Turn your fitness and nutrition goals into an epic RPG adventure. Complete quests, earn XP, and become the hero of your own story.
          </p>
          
          <Button
            onClick={() => window.location.href = '/api/login'}
            size="lg"
            className="h-16 px-12 text-xl font-display tracking-wider bg-primary text-primary-foreground hover:bg-primary/90 shadow-[0_0_30px_rgba(0,200,255,0.3)] border-2 border-primary"
          >
            <Sword className="mr-3 h-6 w-6" />
            START YOUR QUEST
          </Button>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto mb-16">
          <Card className="bg-card/60 backdrop-blur-md border-quest-movement p-6 border-l-4">
            <Zap className="w-12 h-12 text-quest-movement mb-4" />
            <h3 className="text-xl font-display font-bold mb-2">QUEST SYSTEM</h3>
            <p className="text-muted-foreground">
              Create custom fitness and nutrition quests. Track progress across Movement, Nutrition, Recovery, and Mindset realms.
            </p>
          </Card>

          <Card className="bg-card/60 backdrop-blur-md border-quest-nutrition p-6 border-l-4">
            <Trophy className="w-12 h-12 text-quest-nutrition mb-4" />
            <h3 className="text-xl font-display font-bold mb-2">XP & LEVELS</h3>
            <p className="text-muted-foreground">
              Earn experience points for completing quests. Level up and unlock achievements as you progress on your journey.
            </p>
          </Card>

          <Card className="bg-card/60 backdrop-blur-md border-quest-mindset p-6 border-l-4">
            <Shield className="w-12 h-12 text-quest-mindset mb-4" />
            <h3 className="text-xl font-display font-bold mb-2">TRACK PROGRESS</h3>
            <p className="text-muted-foreground">
              Monitor calories, view category progress, and see detailed stats. Your dashboard is your command center.
            </p>
          </Card>
        </div>

        {/* Premium Teaser */}
        <Card className="bg-gradient-to-br from-yellow-500/10 to-purple-500/10 border-yellow-500/30 p-8 max-w-3xl mx-auto backdrop-blur-md">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Crown className="w-8 h-8 text-yellow-500" />
            <h2 className="text-3xl font-display font-bold text-yellow-500">PREMIUM TIER</h2>
          </div>
          <p className="text-center text-muted-foreground mb-6">
            Unlock unlimited quests, advanced analytics, exclusive themes, and premium-only rewards. Upgrade your adventure to legendary status.
          </p>
          <div className="text-center">
            <Button
              onClick={() => window.location.href = '/api/login'}
              variant="outline"
              className="border-yellow-500 text-yellow-500 hover:bg-yellow-500/10"
            >
              Login to Upgrade
            </Button>
          </div>
        </Card>

        {/* Footer */}
        <div className="text-center mt-16 text-muted-foreground font-mono text-sm">
          <p>SYSTEM ONLINE // READY FOR DEPLOYMENT</p>
        </div>
      </div>
    </div>
  );
}
