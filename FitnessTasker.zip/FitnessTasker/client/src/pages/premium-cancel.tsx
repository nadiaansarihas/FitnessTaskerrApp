import { useLocation } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { XCircle } from "lucide-react";

export default function PremiumCancel() {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <Card className="max-w-md w-full p-8 text-center bg-card/80 backdrop-blur-md">
        <XCircle className="w-20 h-20 text-muted-foreground mx-auto mb-4" />
        
        <h1 className="text-3xl font-display font-bold mb-4">
          UPGRADE CANCELLED
        </h1>
        
        <p className="text-muted-foreground mb-6">
          No worries! You can upgrade to Premium anytime from your dashboard.
        </p>
        
        <Button
          onClick={() => setLocation("/")}
          variant="outline"
        >
          BACK TO DASHBOARD
        </Button>
      </Card>
    </div>
  );
}
