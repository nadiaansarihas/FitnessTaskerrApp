import { useLocation } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import { 
  WorkoutType, 
  WORKOUT_TYPES, 
  WORKOUT_TYPE_COLORS, 
  WORKOUT_TYPE_INFO 
} from "@/lib/types";
import { 
  Dumbbell, 
  Heart, 
  Zap, 
  Flower2, 
  Trophy, 
  Sparkles,
  ArrowLeft,
  Plus
} from "lucide-react";
import generatedImage from '@assets/generated_images/dark_sci-fi_hex_grid_background.png';

const WORKOUT_ICONS: Record<WorkoutType, React.ReactNode> = {
  Strength: <Dumbbell className="w-8 h-8" />,
  Cardio: <Heart className="w-8 h-8" />,
  HIIT: <Zap className="w-8 h-8" />,
  Yoga: <Flower2 className="w-8 h-8" />,
  Sports: <Trophy className="w-8 h-8" />,
  Custom: <Sparkles className="w-8 h-8" />,
};

export default function WorkoutLibrary() {
  const { user, isLoading } = useAuth();
  const [, setLocation] = useLocation();

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-4xl font-display text-primary animate-pulse">LOADING...</div>
      </div>
    );
  }

  if (!user) {
    setLocation("/");
    return null;
  }

  return (
    <div className="min-h-screen text-foreground font-sans">
      <div className="fixed inset-0 z-[-1] opacity-20 pointer-events-none">
        <img src={generatedImage} alt="" className="w-full h-full object-cover" />
      </div>

      <div className="container mx-auto px-4 py-8 max-w-6xl">
        <header className="mb-10 flex items-center gap-4">
          <Button
            variant="ghost"
            onClick={() => setLocation("/")}
            className="text-muted-foreground hover:text-foreground"
            data-testid="button-back"
          >
            <ArrowLeft className="w-5 h-5 mr-2" />
            Back
          </Button>
          <div>
            <h1 className="text-4xl font-display font-bold bg-gradient-to-r from-primary via-blue-400 to-purple-500 bg-clip-text text-transparent">
              WORKOUT LIBRARY
            </h1>
            <p className="text-muted-foreground font-mono text-sm">
              BROWSE WORKOUT REALMS // SELECT YOUR TRAINING PATH
            </p>
          </div>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {WORKOUT_TYPES.map((type) => {
            const colors = WORKOUT_TYPE_COLORS[type];
            const info = WORKOUT_TYPE_INFO[type];
            const icon = WORKOUT_ICONS[type];

            return (
              <Card
                key={type}
                className={`bg-card/60 backdrop-blur-md border-2 ${colors} p-6 hover:scale-[1.02] transition-transform cursor-pointer group`}
                data-testid={`card-workout-${type.toLowerCase()}`}
              >
                <div className="flex items-start gap-4 mb-4">
                  <div className={`p-3 rounded-lg ${colors}`}>
                    {icon}
                  </div>
                  <div>
                    <h3 className="text-2xl font-display font-bold">{type.toUpperCase()}</h3>
                    <p className="text-sm text-muted-foreground mt-1">
                      {info.description}
                    </p>
                  </div>
                </div>

                <div className="space-y-2 mb-4">
                  <p className="text-xs font-mono text-muted-foreground uppercase">
                    Sample Activities:
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {info.examples.slice(0, 4).map((example, idx) => (
                      <span
                        key={idx}
                        className={`text-xs px-2 py-1 rounded border ${colors}`}
                      >
                        {example}
                      </span>
                    ))}
                  </div>
                </div>

                <Button
                  variant="outline"
                  className={`w-full ${colors} border-2 hover:bg-current/10 group-hover:shadow-lg transition-all`}
                  onClick={() => setLocation(`/?workoutType=${type}`)}
                  data-testid={`button-create-${type.toLowerCase()}-quest`}
                >
                  <Plus className="w-4 h-4 mr-2" />
                  CREATE {type.toUpperCase()} QUEST
                </Button>
              </Card>
            );
          })}
        </div>

        <Card className="mt-8 bg-card/40 backdrop-blur-md border-primary/20 p-6">
          <h2 className="text-xl font-display text-primary mb-4">HOW WORKOUT TYPES WORK</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-muted-foreground">
            <div>
              <h4 className="font-bold text-foreground mb-2">Tagging Quests</h4>
              <p>
                When you create a new quest in the Movement category, you can optionally 
                tag it with a workout type. This helps you organize your training and 
                track progress across different training styles.
              </p>
            </div>
            <div>
              <h4 className="font-bold text-foreground mb-2">Category Integration</h4>
              <p>
                Workout types work alongside your existing quest categories. A "Bench Press" 
                quest would be categorized as Movement and tagged as Strength training.
              </p>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
