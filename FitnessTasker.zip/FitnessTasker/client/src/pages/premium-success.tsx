import { useEffect } from "react";
import { useLocation } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Crown, CheckCircle } from "lucide-react";

export default function PremiumSuccess() {
  const [, setLocation] = useLocation();

  useEffect(() => {
    // Redirect to dashboard after 3 seconds
    const timer = setTimeout(() => {
      setLocation("/");
    }, 3000);

    return () => clearTimeout(timer);
  }, [setLocation]);

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <Card className="max-w-md w-full p-8 text-center bg-gradient-to-br from-yellow-500/10 to-purple-500/10 border-yellow-500/30 backdrop-blur-md">
        <div className="mb-6">
          <CheckCircle className="w-20 h-20 text-green-500 mx-auto mb-4" />
          <Crown className="w-16 h-16 text-yellow-500 mx-auto animate-pulse" />
        </div>
        
        <h1 className="text-4xl font-display font-bold text-yellow-500 mb-4">
          UPGRADE COMPLETE!
        </h1>
        
        <p className="text-muted-foreground mb-6">
          Welcome to Premium! You now have access to all legendary features.
        </p>
        
        <Button
          onClick={() => setLocation("/")}
          className="bg-yellow-500 text-black hover:bg-yellow-600"
        >
          GO TO DASHBOARD
        </Button>
        
        <p className="text-xs text-muted-foreground mt-4">
          Redirecting automatically in 3 seconds...
        </p>
      </Card>
    </div>
  );
}
