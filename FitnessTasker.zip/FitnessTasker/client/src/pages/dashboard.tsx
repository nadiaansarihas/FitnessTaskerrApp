import { useState, useEffect } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import type { Quest as DBQuest } from "@shared/schema";
import { Category, Difficulty, DIFFICULTY_XP } from "@/lib/types";
import { QuestCard } from "@/components/quest-card";
import { QuestForm } from "@/components/quest-form";
import { StatsPanel } from "@/components/stats-panel";
import { CategoryFilter } from "@/components/category-filter";
import { PremiumBanner } from "@/components/premium-banner";
import { ProgressDashboard } from "@/components/progress-dashboard";
import { QuickAdd } from "@/components/quick-add";
import { motion, AnimatePresence, Reorder } from "framer-motion";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Dumbbell, Link, GripVertical } from "lucide-react";
import generatedImage from '@assets/generated_images/dark_sci-fi_hex_grid_background.png';

// Use database quest type directly
type Quest = DBQuest;

export default function Dashboard() {
  const { user, isLoading: authLoading } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [, setLocation] = useLocation();
  const [filter, setFilter] = useState<Category | 'All'>('All');
  const [xp, setXp] = useState(0);
  const [level, setLevel] = useState(1);

  // Fetch quests from API
  const { data: quests = [], isLoading } = useQuery<Quest[]>({
    queryKey: ["/api/quests"],
    enabled: !!user,
  });

  // Calculate XP from completed quests
  useEffect(() => {
    const totalXp = quests.filter(q => q.completed).reduce((sum, q) => sum + q.xp, 0);
    setXp(totalXp);
    setLevel(Math.floor(totalXp / 1000) + 1);
  }, [quests]);

  // Create quest mutation
  const createQuestMutation = useMutation({
    mutationFn: async (newQuest: { title: string; category: string; difficulty: string; workoutType?: string; calories: number; xp: number }) => {
      const res = await fetch("/api/quests", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newQuest),
      });
      if (!res.ok) {
        const error = await res.text();
        throw new Error(`${res.status}: ${error}`);
      }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/quests"] });
      toast({
        title: "NEW QUEST ACCEPTED",
        description: "Quest added to your log.",
      });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => { window.location.href = "/api/login"; }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to create quest",
        variant: "destructive",
      });
    },
  });

  // Toggle quest mutation
  const toggleQuestMutation = useMutation({
    mutationFn: async ({ id, completed }: { id: string; completed: boolean }) => {
      const res = await fetch(`/api/quests/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ completed }),
      });
      if (!res.ok) throw new Error("Failed to update quest");
      return res.json();
    },
    onSuccess: (data, variables) => {
      queryClient.invalidateQueries({ queryKey: ["/api/quests"] });
      if (variables.completed) {
        const quest = quests.find(q => q.id === variables.id);
        if (quest) {
          toast({
            title: "QUEST COMPLETED!",
            description: `+${quest.xp} XP Gained`,
            className: "bg-primary text-primary-foreground border-none font-display",
          });
        }
      }
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => { window.location.href = "/api/login"; }, 500);
      }
    },
  });

  // Delete quest mutation
  const deleteQuestMutation = useMutation({
    mutationFn: async (id: string) => {
      const res = await fetch(`/api/quests/${id}`, {
        method: "DELETE",
      });
      if (!res.ok) throw new Error("Failed to delete quest");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/quests"] });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => { window.location.href = "/api/login"; }, 500);
      }
    },
  });

  // Edit quest mutation
  const editQuestMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: string; updates: Partial<Quest> }) => {
      const res = await fetch(`/api/quests/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updates),
      });
      if (!res.ok) throw new Error("Failed to update quest");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/quests"] });
      toast({
        title: "QUEST UPDATED",
        description: "Quest has been modified.",
      });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => { window.location.href = "/api/login"; }, 500);
      }
    },
  });

  // Reorder quests mutation with optimistic update and rollback
  const reorderQuestsMutation = useMutation({
    mutationFn: async (orderedIds: string[]) => {
      const res = await fetch('/api/quests/reorder', {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ orderedIds }),
      });
      if (!res.ok) throw new Error("Failed to reorder quests");
      return res.json();
    },
    onMutate: async (orderedIds: string[]) => {
      await queryClient.cancelQueries({ queryKey: ["/api/quests"] });
      const previousQuests = queryClient.getQueryData<Quest[]>(["/api/quests"]);
      
      if (previousQuests) {
        const questMap = new Map(previousQuests.map(q => [q.id, q]));
        const reorderedQuests = orderedIds
          .map((id, idx) => {
            const quest = questMap.get(id);
            return quest ? { ...quest, sortOrder: idx } : null;
          })
          .filter((q): q is Quest => q !== null);
        
        queryClient.setQueryData(["/api/quests"], reorderedQuests);
      }
      
      return { previousQuests };
    },
    onError: (error: Error, _orderedIds, context) => {
      if (context?.previousQuests) {
        queryClient.setQueryData(["/api/quests"], context.previousQuests);
      }
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => { window.location.href = "/api/login"; }, 500);
      }
    },
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/quests"] });
    },
  });

  const addQuest = (newQuest: { title: string; category: string; difficulty: string; workoutType?: string; calories: number }) => {
    const difficulty = newQuest.difficulty as Difficulty;
    const xpReward = DIFFICULTY_XP[difficulty];
    createQuestMutation.mutate({
      ...newQuest,
      xp: xpReward,
    });
  };

  const toggleQuest = (id: string) => {
    const quest = quests.find(q => q.id === id);
    if (quest) {
      toggleQuestMutation.mutate({ id, completed: !quest.completed });
    }
  };

  const deleteQuest = (id: string) => {
    deleteQuestMutation.mutate(id);
  };

  const editQuest = (id: string, updates: Partial<Quest>) => {
    editQuestMutation.mutate({ id, updates });
  };

  const quickAddQuest = (title: string) => {
    createQuestMutation.mutate({
      title,
      category: 'Other',
      difficulty: 'Normal',
      calories: 0,
      xp: DIFFICULTY_XP.Normal,
    });
  };

  const handleReorder = (newOrder: Quest[]) => {
    const orderedIds = newOrder.map(q => q.id);
    reorderQuestsMutation.mutate(orderedIds);
  };

  const filteredQuests = quests.filter(q => {
    if (filter === 'All') return true;
    return q.category === filter;
  });

  const nextLevelXp = level * 1000;

  // Show loading while auth or quests are loading
  if (authLoading || isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="text-4xl font-display text-primary animate-pulse mb-4">LOADING...</div>
          <p className="text-muted-foreground font-mono">Initializing Quest System</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen text-foreground font-sans selection:bg-primary/30">
      {/* Background Image Layer */}
      <div className="fixed inset-0 z-[-1] opacity-20 pointer-events-none">
        <img src={generatedImage} alt="" className="w-full h-full object-cover" />
      </div>
      
      <div className="container mx-auto px-4 py-8 max-w-6xl">
        <header className="mb-10 border-b border-primary/20 pb-6">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
            <div>
              <h1 className="text-4xl md:text-6xl font-display font-bold bg-gradient-to-r from-primary via-blue-400 to-purple-500 bg-clip-text text-transparent animate-pulse">
                QUESTLOG
              </h1>
              <p className="text-muted-foreground mt-2 font-mono text-sm">
                SYSTEM: ONLINE // USER: {user?.email || 'AGENT'}
              </p>
            </div>
            <div className="flex items-center gap-4">
              <button
                onClick={() => setLocation('/workout-library')}
                className="text-muted-foreground hover:text-primary transition-colors font-mono text-sm flex items-center gap-1"
                data-testid="button-workout-library"
              >
                <Dumbbell className="w-4 h-4" />
                WORKOUTS
              </button>
              <button
                onClick={() => setLocation('/integrations')}
                className="text-muted-foreground hover:text-primary transition-colors font-mono text-sm flex items-center gap-1"
                data-testid="button-integrations"
              >
                <Link className="w-4 h-4" />
                INTEGRATIONS
              </button>
              <button
                onClick={() => window.location.href = '/api/logout'}
                className="text-muted-foreground hover:text-foreground transition-colors font-mono text-sm"
                data-testid="button-logout"
              >
                [ LOGOUT ]
              </button>
            </div>
          </div>
        </header>

        {/* Premium Banner */}
        {user && !user.isPremium && <PremiumBanner />}

        {/* Progress Dashboard */}
        <ProgressDashboard quests={quests as any} />

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Quest Log Area */}
          <div className="lg:col-span-2 space-y-6">
            {/* Quick Add */}
            <QuickAdd onAdd={quickAddQuest} />
            
            <QuestForm onAddQuest={addQuest} />
            
            <div>
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-display text-primary/80">ACTIVE QUESTS</h2>
                <span className="text-xs font-mono text-muted-foreground">
                  {filteredQuests.length} DETECTED
                  {user?.isPremium && <span className="ml-2 text-yellow-500">[ PREMIUM ]</span>}
                </span>
              </div>
              
              <CategoryFilter selected={filter} onSelect={setFilter} />

              {filter === 'All' ? (
                <Reorder.Group 
                  axis="y" 
                  values={quests} 
                  onReorder={handleReorder}
                  className="space-y-4"
                >
                  <AnimatePresence mode="popLayout">
                    {quests.length === 0 ? (
                      <motion.div 
                        initial={{ opacity: 0 }} 
                        animate={{ opacity: 1 }}
                        className="text-center py-12 border-2 border-dashed border-muted rounded-lg"
                      >
                        <p className="text-muted-foreground font-mono">NO QUESTS FOUND IN THIS SECTOR</p>
                      </motion.div>
                    ) : (
                      quests.map(quest => (
                        <Reorder.Item
                          key={quest.id}
                          value={quest}
                          className="cursor-grab active:cursor-grabbing"
                          whileDrag={{ 
                            scale: 1.02, 
                            boxShadow: "0 0 20px rgba(0, 255, 255, 0.3)",
                            zIndex: 50 
                          }}
                        >
                          <div className="flex items-center gap-2">
                            <div className="flex-shrink-0 text-muted-foreground/50 hover:text-primary transition-colors">
                              <GripVertical className="w-5 h-5" />
                            </div>
                            <div className="flex-1">
                              <QuestCard 
                                quest={quest as any} 
                                onToggle={toggleQuest} 
                                onDelete={deleteQuest}
                                onEdit={editQuest}
                              />
                            </div>
                          </div>
                        </Reorder.Item>
                      ))
                    )}
                  </AnimatePresence>
                </Reorder.Group>
              ) : (
                <div className="space-y-4">
                  <AnimatePresence mode="popLayout">
                    {filteredQuests.length === 0 ? (
                      <motion.div 
                        initial={{ opacity: 0 }} 
                        animate={{ opacity: 1 }}
                        className="text-center py-12 border-2 border-dashed border-muted rounded-lg"
                      >
                        <p className="text-muted-foreground font-mono">NO QUESTS FOUND IN THIS SECTOR</p>
                      </motion.div>
                    ) : (
                      filteredQuests.map(quest => (
                        <QuestCard 
                          key={quest.id} 
                          quest={quest as any} 
                          onToggle={toggleQuest} 
                          onDelete={deleteQuest}
                          onEdit={editQuest}
                        />
                      ))
                    )}
                  </AnimatePresence>
                </div>
              )}
            </div>
          </div>

          {/* Sidebar Stats */}
          <div className="lg:col-span-1">
            <StatsPanel 
              quests={quests as any} 
              xp={xp} 
              level={level} 
              nextLevelXp={nextLevelXp} 
            />
          </div>
        </div>
      </div>
    </div>
  );
}
