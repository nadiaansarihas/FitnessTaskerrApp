import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { 
  ArrowLeft, 
  Utensils, 
  Heart, 
  Activity, 
  Watch,
  Link,
  Unlink,
  RefreshCw,
  AlertCircle,
  CheckCircle
} from "lucide-react";
import generatedImage from '@assets/generated_images/dark_sci-fi_hex_grid_background.png';

interface Integration {
  id: string;
  name: string;
  description: string;
  connected: boolean;
  lastSyncAt: string | null;
  icon: string;
}

const INTEGRATION_ICONS: Record<string, React.ReactNode> = {
  utensils: <Utensils className="w-6 h-6" />,
  heart: <Heart className="w-6 h-6" />,
  activity: <Activity className="w-6 h-6" />,
  watch: <Watch className="w-6 h-6" />,
};

const INTEGRATION_COLORS: Record<string, string> = {
  myfitnesspal: 'text-blue-500 border-blue-500',
  'apple-health': 'text-red-500 border-red-500',
  'google-fit': 'text-green-500 border-green-500',
  'apple-watch': 'text-pink-500 border-pink-500',
};

export default function Integrations() {
  const { user, isLoading: authLoading } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [syncingId, setSyncingId] = useState<string | null>(null);

  const { data: integrations = [], isLoading } = useQuery<Integration[]>({
    queryKey: ["/api/integrations"],
    enabled: !!user,
  });

  const connectMutation = useMutation({
    mutationFn: async (serviceId: string) => {
      const res = await fetch(`/api/integrations/${serviceId}/connect`, {
        method: "POST",
      });
      if (!res.ok) throw new Error("Failed to connect");
      return res.json();
    },
    onSuccess: (data) => {
      if (data.authUrl) {
        window.location.href = data.authUrl;
      } else {
        queryClient.invalidateQueries({ queryKey: ["/api/integrations"] });
        toast({
          title: "Connected!",
          description: data.message || "Integration connected successfully.",
        });
      }
    },
    onError: () => {
      toast({
        title: "Connection Failed",
        description: "Unable to connect to this service. Please try again.",
        variant: "destructive",
      });
    },
  });

  const disconnectMutation = useMutation({
    mutationFn: async (serviceId: string) => {
      const res = await fetch(`/api/integrations/${serviceId}/disconnect`, {
        method: "POST",
      });
      if (!res.ok) throw new Error("Failed to disconnect");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/integrations"] });
      toast({
        title: "Disconnected",
        description: "Integration disconnected successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to disconnect integration.",
        variant: "destructive",
      });
    },
  });

  const syncMutation = useMutation({
    mutationFn: async (serviceId: string) => {
      setSyncingId(serviceId);
      const res = await fetch(`/api/integrations/${serviceId}/sync`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ date: new Date().toISOString().split('T')[0] }),
      });
      if (!res.ok) throw new Error("Failed to sync");
      return res.json();
    },
    onSuccess: (data) => {
      setSyncingId(null);
      toast({
        title: "Sync Complete!",
        description: "Data has been synced successfully.",
      });
      console.log("Synced data:", data);
    },
    onError: () => {
      setSyncingId(null);
      toast({
        title: "Sync Failed",
        description: "Unable to sync data. Please try again.",
        variant: "destructive",
      });
    },
  });

  if (authLoading || isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-4xl font-display text-primary animate-pulse">LOADING...</div>
      </div>
    );
  }

  if (!user) {
    setLocation("/");
    return null;
  }

  return (
    <div className="min-h-screen text-foreground font-sans">
      <div className="fixed inset-0 z-[-1] opacity-20 pointer-events-none">
        <img src={generatedImage} alt="" className="w-full h-full object-cover" />
      </div>

      <div className="container mx-auto px-4 py-8 max-w-4xl">
        <header className="mb-10 flex items-center gap-4">
          <Button
            variant="ghost"
            onClick={() => setLocation("/")}
            className="text-muted-foreground hover:text-foreground"
            data-testid="button-back"
          >
            <ArrowLeft className="w-5 h-5 mr-2" />
            Back
          </Button>
          <div>
            <h1 className="text-4xl font-display font-bold bg-gradient-to-r from-primary via-blue-400 to-purple-500 bg-clip-text text-transparent">
              INTEGRATIONS
            </h1>
            <p className="text-muted-foreground font-mono text-sm">
              CONNECT EXTERNAL DATA SOURCES // SYNC YOUR HEALTH DATA
            </p>
          </div>
        </header>

        <Card className="mb-6 bg-yellow-500/10 border-yellow-500/30 p-4">
          <div className="flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-yellow-500 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm text-yellow-500 font-medium">Integration Stubs</p>
              <p className="text-xs text-muted-foreground mt-1">
                These integrations are currently placeholders. They return mock data for development. 
                To fully implement them, you'll need to register apps with each provider and add the 
                appropriate API credentials.
              </p>
            </div>
          </div>
        </Card>

        <div className="space-y-4">
          {integrations.map((integration) => {
            const colors = INTEGRATION_COLORS[integration.id] || 'text-primary border-primary';
            const icon = INTEGRATION_ICONS[integration.icon] || <Activity className="w-6 h-6" />;
            const isSyncing = syncingId === integration.id;

            return (
              <Card
                key={integration.id}
                className={`bg-card/60 backdrop-blur-md border ${integration.connected ? 'border-green-500/50' : 'border-muted'} p-6`}
                data-testid={`card-integration-${integration.id}`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className={`p-3 rounded-lg bg-card border ${colors}`}>
                      {icon}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="text-xl font-display font-bold">{integration.name}</h3>
                        {integration.connected && (
                          <CheckCircle className="w-4 h-4 text-green-500" />
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground">
                        {integration.description}
                      </p>
                      {integration.lastSyncAt && (
                        <p className="text-xs text-muted-foreground mt-1 font-mono">
                          Last sync: {new Date(integration.lastSyncAt).toLocaleString()}
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    {integration.connected ? (
                      <>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => syncMutation.mutate(integration.id)}
                          disabled={isSyncing}
                          className={colors}
                          data-testid={`button-sync-${integration.id}`}
                        >
                          <RefreshCw className={`w-4 h-4 mr-2 ${isSyncing ? 'animate-spin' : ''}`} />
                          {isSyncing ? 'Syncing...' : 'Sync'}
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => disconnectMutation.mutate(integration.id)}
                          className="text-red-500 border-red-500 hover:bg-red-500/10"
                          data-testid={`button-disconnect-${integration.id}`}
                        >
                          <Unlink className="w-4 h-4 mr-2" />
                          Disconnect
                        </Button>
                      </>
                    ) : (
                      <Button
                        onClick={() => connectMutation.mutate(integration.id)}
                        disabled={connectMutation.isPending}
                        className={`bg-primary hover:bg-primary/90`}
                        data-testid={`button-connect-${integration.id}`}
                      >
                        <Link className="w-4 h-4 mr-2" />
                        Connect
                      </Button>
                    )}
                  </div>
                </div>
              </Card>
            );
          })}
        </div>

        <Card className="mt-8 bg-card/40 backdrop-blur-md border-primary/20 p-6">
          <h2 className="text-xl font-display text-primary mb-4">INTEGRATION NOTES</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-muted-foreground">
            <div>
              <h4 className="font-bold text-foreground mb-2">MyFitnessPal & Google Fit</h4>
              <p>
                These integrations use OAuth 2.0. Clicking "Connect" will redirect you to 
                their login pages. You'll need to register your app with each provider to 
                get real API access.
              </p>
            </div>
            <div>
              <h4 className="font-bold text-foreground mb-2">Apple Health & Watch</h4>
              <p>
                Apple Health data is only accessible from iOS devices via HealthKit. 
                To fully implement this, you'll need a companion iOS app or use a 
                third-party bridging service like Terra API.
              </p>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
