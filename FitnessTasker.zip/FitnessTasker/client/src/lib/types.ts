export type Category = 'Movement' | 'Nutrition' | 'Recovery' | 'Mindset' | 'Other';
export type Difficulty = 'Easy' | 'Normal' | 'Epic';
export type WorkoutType = 'Strength' | 'Cardio' | 'HIIT' | 'Yoga' | 'Sports' | 'Custom';

export interface Quest {
  id: string;
  userId: string;
  title: string;
  category: string;
  difficulty: string;
  workoutType?: string | null;
  calories: number | null;
  completed: boolean;
  xp: number;
  createdAt: Date;
}

export const CATEGORY_COLORS: Record<Category, string> = {
  Movement: 'text-quest-movement border-quest-movement bg-quest-movement/10',
  Nutrition: 'text-quest-nutrition border-quest-nutrition bg-quest-nutrition/10',
  Recovery: 'text-quest-recovery border-quest-recovery bg-quest-recovery/10',
  Mindset: 'text-quest-mindset border-quest-mindset bg-quest-mindset/10',
  Other: 'text-quest-other border-quest-other bg-quest-other/10',
};

export const CATEGORY_BG_COLORS: Record<Category, string> = {
    Movement: 'bg-quest-movement',
    Nutrition: 'bg-quest-nutrition',
    Recovery: 'bg-quest-recovery',
    Mindset: 'bg-quest-mindset',
    Other: 'bg-quest-other',
};

export const DIFFICULTY_XP: Record<Difficulty, number> = {
  Easy: 50,
  Normal: 150,
  Epic: 500,
};

export const DIFFICULTY_COLORS: Record<Difficulty, string> = {
  Easy: 'text-diff-easy border-diff-easy',
  Normal: 'text-diff-normal border-diff-normal',
  Epic: 'text-diff-epic border-diff-epic animate-pulse',
};

// Workout Types with colors and icons
export const WORKOUT_TYPES: WorkoutType[] = ['Strength', 'Cardio', 'HIIT', 'Yoga', 'Sports', 'Custom'];

export const WORKOUT_TYPE_COLORS: Record<WorkoutType, string> = {
  Strength: 'text-red-500 border-red-500 bg-red-500/10',
  Cardio: 'text-orange-500 border-orange-500 bg-orange-500/10',
  HIIT: 'text-yellow-500 border-yellow-500 bg-yellow-500/10',
  Yoga: 'text-purple-500 border-purple-500 bg-purple-500/10',
  Sports: 'text-green-500 border-green-500 bg-green-500/10',
  Custom: 'text-gray-400 border-gray-400 bg-gray-400/10',
};

export const WORKOUT_TYPE_INFO: Record<WorkoutType, { description: string; examples: string[] }> = {
  Strength: {
    description: 'Build muscle and increase raw power through resistance training',
    examples: ['Bench Press', 'Squats', 'Deadlifts', 'Pull-ups', 'Dumbbell Rows'],
  },
  Cardio: {
    description: 'Improve cardiovascular endurance and burn calories',
    examples: ['Running', 'Cycling', 'Swimming', 'Jump Rope', 'Rowing'],
  },
  HIIT: {
    description: 'High-intensity interval training for maximum calorie burn',
    examples: ['Burpees Circuit', 'Tabata Sprints', 'Box Jumps', 'Battle Ropes', 'Kettlebell Swings'],
  },
  Yoga: {
    description: 'Flexibility, balance, and mindfulness practice',
    examples: ['Vinyasa Flow', 'Power Yoga', 'Yin Yoga', 'Sun Salutations', 'Stretching'],
  },
  Sports: {
    description: 'Competitive and recreational athletic activities',
    examples: ['Basketball', 'Soccer', 'Tennis', 'Rock Climbing', 'Martial Arts'],
  },
  Custom: {
    description: 'Create your own unique workout routines',
    examples: ['Mixed Training', 'Rehabilitation', 'Dance Fitness', 'Outdoor Adventure'],
  },
};
