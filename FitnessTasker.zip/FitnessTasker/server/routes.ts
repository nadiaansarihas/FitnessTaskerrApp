import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { insertQuestSchema } from "@shared/schema";
import Stripe from "stripe";
import { getIntegrationStatuses, myFitnessPalService, appleHealthService, googleFitService, appleWatchService } from "./services";

// Initialize Stripe only if keys are provided
const stripe = process.env.STRIPE_SECRET_KEY 
  ? new Stripe(process.env.STRIPE_SECRET_KEY, {
      apiVersion: '2025-11-17.clover',
    })
  : null;

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Setup authentication middleware
  await setupAuth(app);

  // ==================== AUTH ROUTES ====================
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // ==================== QUEST ROUTES ====================
  
  // Get all quests for the logged-in user
  app.get('/api/quests', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const quests = await storage.getQuestsByUserId(userId);
      res.json(quests);
    } catch (error) {
      console.error("Error fetching quests:", error);
      res.status(500).json({ message: "Failed to fetch quests" });
    }
  });

  // Create a new quest
  app.post('/api/quests', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const validatedData = insertQuestSchema.parse(req.body);
      
      const quest = await storage.createQuest({
        ...validatedData,
        userId,
      });
      
      res.status(201).json(quest);
    } catch (error) {
      console.error("Error creating quest:", error);
      res.status(400).json({ message: "Failed to create quest" });
    }
  });

  // Update a quest (toggle complete, edit, etc.)
  app.patch('/api/quests/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { id } = req.params;
      
      const quest = await storage.updateQuest(id, userId, req.body);
      
      if (!quest) {
        return res.status(404).json({ message: "Quest not found" });
      }
      
      res.json(quest);
    } catch (error) {
      console.error("Error updating quest:", error);
      res.status(400).json({ message: "Failed to update quest" });
    }
  });

  // Delete a quest
  app.delete('/api/quests/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { id } = req.params;
      
      const deleted = await storage.deleteQuest(id, userId);
      
      if (!deleted) {
        return res.status(404).json({ message: "Quest not found" });
      }
      
      res.json({ message: "Quest deleted" });
    } catch (error) {
      console.error("Error deleting quest:", error);
      res.status(500).json({ message: "Failed to delete quest" });
    }
  });

  // Reorder quests
  app.put('/api/quests/reorder', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { orderedIds } = req.body;
      
      if (!Array.isArray(orderedIds)) {
        return res.status(400).json({ message: "orderedIds must be an array" });
      }
      
      // Validate that orderedIds matches user's quests
      const userQuests = await storage.getQuestsByUserId(userId);
      const userQuestIds = new Set(userQuests.map(q => q.id));
      const orderedIdsSet = new Set(orderedIds);
      
      // Check for duplicates
      if (orderedIds.length !== orderedIdsSet.size) {
        return res.status(400).json({ message: "orderedIds contains duplicates" });
      }
      
      // Check all orderedIds belong to user
      for (const id of orderedIds) {
        if (!userQuestIds.has(id)) {
          return res.status(400).json({ message: "orderedIds contains invalid quest ID" });
        }
      }
      
      // Check all user quests are included
      if (orderedIds.length !== userQuests.length) {
        return res.status(400).json({ message: "orderedIds must include all user quests" });
      }
      
      await storage.reorderQuests(userId, orderedIds);
      res.json({ message: "Quests reordered" });
    } catch (error) {
      console.error("Error reordering quests:", error);
      res.status(500).json({ message: "Failed to reorder quests" });
    }
  });

  // ==================== STRIPE BILLING ROUTES ====================
  
  // Create Stripe Checkout Session for premium subscription
  app.post('/api/billing/create-checkout-session', isAuthenticated, async (req: any, res) => {
    try {
      if (!stripe) {
        return res.status(503).json({ message: "Stripe is not configured. Please add STRIPE_SECRET_KEY and STRIPE_PRICE_ID environment variables." });
      }

      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Check if user is already premium
      if (user.isPremium) {
        return res.status(400).json({ message: "User is already premium" });
      }

      // Create or retrieve Stripe customer
      let customerId = user.stripeCustomerId;
      
      if (!customerId) {
        const customer = await stripe.customers.create({
          email: user.email || undefined,
          metadata: {
            userId: user.id,
          },
        });
        customerId = customer.id;
        await storage.updateUserPremiumStatus(userId, false, customerId);
      }

      // Create Checkout Session
      // Replace PRICE_ID with your actual Stripe Price ID from the dashboard
      const session = await stripe.checkout.sessions.create({
        customer: customerId,
        mode: 'subscription',
        payment_method_types: ['card'],
        line_items: [
          {
            price: process.env.STRIPE_PRICE_ID || 'price_1234567890', // Replace with your test price ID
            quantity: 1,
          },
        ],
        success_url: `${req.protocol}://${req.hostname}/premium-success?session_id={CHECKOUT_SESSION_ID}`,
        cancel_url: `${req.protocol}://${req.hostname}/premium-cancel`,
        metadata: {
          userId: user.id,
        },
      });

      res.json({ url: session.url });
    } catch (error) {
      console.error("Error creating checkout session:", error);
      res.status(500).json({ message: "Failed to create checkout session" });
    }
  });

  // Stripe webhook handler
  app.post('/api/billing/webhook', async (req, res) => {
    if (!stripe) {
      return res.status(503).send('Stripe is not configured');
    }

    const sig = req.headers['stripe-signature'];
    const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;

    if (!sig || !webhookSecret) {
      return res.status(400).send('Webhook signature or secret missing');
    }

    let event: Stripe.Event;

    try {
      event = stripe.webhooks.constructEvent(req.body, sig, webhookSecret);
    } catch (err: any) {
      console.error('Webhook signature verification failed:', err.message);
      return res.status(400).send(`Webhook Error: ${err.message}`);
    }

    // Handle the event
    try {
      switch (event.type) {
        case 'checkout.session.completed': {
          const session = event.data.object as Stripe.Checkout.Session;
          const userId = session.metadata?.userId;
          
          if (userId && session.subscription) {
            await storage.updateUserPremiumStatus(
              userId, 
              true, 
              session.customer as string,
              session.subscription as string
            );
            console.log(`User ${userId} upgraded to premium`);
          }
          break;
        }
        
        case 'customer.subscription.deleted': {
          const subscription = event.data.object as Stripe.Subscription;
          const customerId = subscription.customer as string;
          
          // Find user by Stripe customer ID and downgrade
          // Note: You might want to add a method to find user by stripeCustomerId
          console.log(`Subscription ${subscription.id} cancelled for customer ${customerId}`);
          break;
        }
      }

      res.json({ received: true });
    } catch (error) {
      console.error('Error handling webhook:', error);
      res.status(500).json({ message: 'Webhook handler failed' });
    }
  });

  // ==================== HEALTH SYNC ROUTES ====================

  // Get all integration statuses
  app.get('/api/integrations', isAuthenticated, async (req: any, res) => {
    try {
      const statuses = getIntegrationStatuses();
      res.json(statuses);
    } catch (error) {
      console.error("Error fetching integrations:", error);
      res.status(500).json({ message: "Failed to fetch integrations" });
    }
  });

  // MyFitnessPal routes
  app.post('/api/integrations/myfitnesspal/connect', isAuthenticated, async (req: any, res) => {
    try {
      const redirectUri = `${req.protocol}://${req.hostname}/api/integrations/myfitnesspal/callback`;
      const authUrl = myFitnessPalService.getAuthorizationUrl(redirectUri);
      res.json({ authUrl });
    } catch (error) {
      console.error("Error connecting MyFitnessPal:", error);
      res.status(500).json({ message: "Failed to initiate connection" });
    }
  });

  app.get('/api/integrations/myfitnesspal/callback', async (req, res) => {
    try {
      const { code } = req.query;
      const redirectUri = `${req.protocol}://${req.hostname}/api/integrations/myfitnesspal/callback`;
      await myFitnessPalService.handleCallback(code as string, redirectUri);
      res.redirect('/integrations?connected=myfitnesspal');
    } catch (error) {
      console.error("Error in MyFitnessPal callback:", error);
      res.redirect('/integrations?error=myfitnesspal');
    }
  });

  app.post('/api/integrations/myfitnesspal/sync', isAuthenticated, async (req: any, res) => {
    try {
      const date = req.body.date || new Date().toISOString().split('T')[0];
      const result = await myFitnessPalService.syncAll(date);
      res.json(result);
    } catch (error) {
      console.error("Error syncing MyFitnessPal:", error);
      res.status(500).json({ message: "Failed to sync data" });
    }
  });

  // Apple Health routes
  app.post('/api/integrations/apple-health/connect', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { deviceId } = req.body;
      const connected = await appleHealthService.connect(userId, deviceId || 'web-client');
      res.json({ connected, message: "Apple Health connection requires iOS app" });
    } catch (error) {
      console.error("Error connecting Apple Health:", error);
      res.status(500).json({ message: "Failed to connect" });
    }
  });

  app.post('/api/integrations/apple-health/sync', isAuthenticated, async (req: any, res) => {
    try {
      const date = req.body.date || new Date().toISOString().split('T')[0];
      const result = await appleHealthService.syncAll(date);
      res.json(result);
    } catch (error) {
      console.error("Error syncing Apple Health:", error);
      res.status(500).json({ message: "Failed to sync data" });
    }
  });

  // Google Fit routes
  app.post('/api/integrations/google-fit/connect', isAuthenticated, async (req: any, res) => {
    try {
      const redirectUri = `${req.protocol}://${req.hostname}/api/integrations/google-fit/callback`;
      const authUrl = googleFitService.getAuthorizationUrl(redirectUri);
      res.json({ authUrl });
    } catch (error) {
      console.error("Error connecting Google Fit:", error);
      res.status(500).json({ message: "Failed to initiate connection" });
    }
  });

  app.get('/api/integrations/google-fit/callback', async (req, res) => {
    try {
      const { code } = req.query;
      const redirectUri = `${req.protocol}://${req.hostname}/api/integrations/google-fit/callback`;
      await googleFitService.handleCallback(code as string, redirectUri);
      res.redirect('/integrations?connected=google-fit');
    } catch (error) {
      console.error("Error in Google Fit callback:", error);
      res.redirect('/integrations?error=google-fit');
    }
  });

  app.post('/api/integrations/google-fit/sync', isAuthenticated, async (req: any, res) => {
    try {
      const date = req.body.date || new Date().toISOString().split('T')[0];
      const result = await googleFitService.syncAll(date);
      res.json(result);
    } catch (error) {
      console.error("Error syncing Google Fit:", error);
      res.status(500).json({ message: "Failed to sync data" });
    }
  });

  // Apple Watch routes
  app.post('/api/integrations/apple-watch/connect', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { deviceId } = req.body;
      const connected = await appleWatchService.registerDevice(userId, deviceId || 'watch-simulator');
      res.json({ connected, message: "Apple Watch connection requires iOS companion app" });
    } catch (error) {
      console.error("Error connecting Apple Watch:", error);
      res.status(500).json({ message: "Failed to connect" });
    }
  });

  app.post('/api/integrations/apple-watch/sync', isAuthenticated, async (req: any, res) => {
    try {
      const date = req.body.date || new Date().toISOString().split('T')[0];
      const result = await appleWatchService.syncAll(date);
      res.json(result);
    } catch (error) {
      console.error("Error syncing Apple Watch:", error);
      res.status(500).json({ message: "Failed to sync data" });
    }
  });

  // Disconnect integrations
  app.post('/api/integrations/:service/disconnect', isAuthenticated, async (req: any, res) => {
    try {
      const { service } = req.params;
      
      switch (service) {
        case 'myfitnesspal':
          myFitnessPalService.disconnect();
          break;
        case 'apple-health':
          appleHealthService.disconnect();
          break;
        case 'google-fit':
          googleFitService.disconnect();
          break;
        case 'apple-watch':
          appleWatchService.disconnect();
          break;
        default:
          return res.status(400).json({ message: "Unknown service" });
      }
      
      res.json({ message: `${service} disconnected` });
    } catch (error) {
      console.error("Error disconnecting service:", error);
      res.status(500).json({ message: "Failed to disconnect" });
    }
  });

  return httpServer;
}
