import {
  users,
  quests,
  type User,
  type UpsertUser,
  type Quest,
  type InsertQuest,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, asc, inArray } from "drizzle-orm";

// Storage interface
export interface IStorage {
  // User operations (required for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  updateUserPremiumStatus(userId: string, isPremium: boolean, stripeCustomerId?: string, stripeSubscriptionId?: string): Promise<User>;
  
  // Quest operations
  getQuestsByUserId(userId: string): Promise<Quest[]>;
  createQuest(quest: InsertQuest): Promise<Quest>;
  updateQuest(id: string, userId: string, updates: Partial<Quest>): Promise<Quest | undefined>;
  deleteQuest(id: string, userId: string): Promise<boolean>;
  reorderQuests(userId: string, orderedIds: string[]): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async updateUserPremiumStatus(
    userId: string, 
    isPremium: boolean, 
    stripeCustomerId?: string, 
    stripeSubscriptionId?: string
  ): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ 
        isPremium, 
        stripeCustomerId, 
        stripeSubscriptionId,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  // Quest operations
  async getQuestsByUserId(userId: string): Promise<Quest[]> {
    return await db
      .select()
      .from(quests)
      .where(eq(quests.userId, userId))
      .orderBy(asc(quests.sortOrder));
  }

  async createQuest(quest: InsertQuest): Promise<Quest> {
    // Get max sortOrder for user's quests
    const existingQuests = await this.getQuestsByUserId(quest.userId);
    const maxOrder = existingQuests.length > 0 
      ? Math.max(...existingQuests.map(q => q.sortOrder)) 
      : -1;
    
    const [newQuest] = await db.insert(quests).values({
      ...quest,
      sortOrder: maxOrder + 1,
    }).returning();
    return newQuest;
  }

  async updateQuest(id: string, userId: string, updates: Partial<Quest>): Promise<Quest | undefined> {
    const [updatedQuest] = await db
      .update(quests)
      .set(updates)
      .where(and(eq(quests.id, id), eq(quests.userId, userId)))
      .returning();
    return updatedQuest;
  }

  async deleteQuest(id: string, userId: string): Promise<boolean> {
    const result = await db
      .delete(quests)
      .where(and(eq(quests.id, id), eq(quests.userId, userId)))
      .returning();
    return result.length > 0;
  }

  async reorderQuests(userId: string, orderedIds: string[]): Promise<void> {
    // Update sortOrder for each quest based on position in array
    await Promise.all(
      orderedIds.map((id, index) =>
        db
          .update(quests)
          .set({ sortOrder: index })
          .where(and(eq(quests.id, id), eq(quests.userId, userId)))
      )
    );
  }
}

export const storage = new DatabaseStorage();
