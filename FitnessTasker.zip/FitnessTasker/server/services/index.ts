/**
 * Health Integration Services Index
 * 
 * This file exports all health sync services for easy importing.
 * Each service is a stub that can be implemented with actual API calls.
 */

export { myFitnessPalService } from './myfitnesspal';
export { appleHealthService } from './appleHealth';
export { googleFitService } from './googleFit';
export { appleWatchService } from './appleWatch';

// Service status type for frontend
export interface IntegrationStatus {
  id: string;
  name: string;
  description: string;
  connected: boolean;
  lastSyncAt: string | null;
  icon: string;
}

export function getIntegrationStatuses(): IntegrationStatus[] {
  return [
    {
      id: 'myfitnesspal',
      name: 'MyFitnessPal',
      description: 'Sync calories, meals, and workouts',
      connected: false, // myFitnessPalService.isConnected()
      lastSyncAt: null,
      icon: 'utensils',
    },
    {
      id: 'apple-health',
      name: 'Apple Health',
      description: 'Sync steps, calories, and workouts from HealthKit',
      connected: false, // appleHealthService.isConnected()
      lastSyncAt: null,
      icon: 'heart',
    },
    {
      id: 'google-fit',
      name: 'Google Fit',
      description: 'Sync activity and workout data',
      connected: false, // googleFitService.isConnected()
      lastSyncAt: null,
      icon: 'activity',
    },
    {
      id: 'apple-watch',
      name: 'Apple Watch',
      description: 'Sync heart rate, activity rings, and sleep data',
      connected: false, // appleWatchService.isConnected()
      lastSyncAt: null,
      icon: 'watch',
    },
  ];
}
